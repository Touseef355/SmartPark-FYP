import random
import time
from twilio.rest import Client
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate,get_user_model  
from django.core.mail import send_mail
from django.core.cache import cache
from .serializers import RegisterSerializer

User = get_user_model()

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        "refresh": str(refresh),
        "access": str(refresh.access_token)
    }


class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            token = get_tokens_for_user(user)
            return Response(
                {"message": "Registered Successfully", "tokens": token},
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")
        user = authenticate(request, email=email, password=password)

        if user is None:
            return Response(
                {"error": "Invalid email or password"},
                status=status.HTTP_401_UNAUTHORIZED
            )
        token = get_tokens_for_user(user)
        site_id = None
        if user.site:
            site_id = str(user.site.id)

        return Response(
                {
                    "message": "Login Successful",
                    "tokens": token,
                    "role"  : user.role,     
                    "name"  : user.full_name,
                    "site_id": site_id,
                },
                status=status.HTTP_200_OK
            )

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data.get("refresh")
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(
                {"message": "Logged out successfully"},
                status=status.HTTP_200_OK
            )
        except Exception:
            return Response(
                {"error": "Invalid token"},
                status=status.HTTP_400_BAD_REQUEST
            )
class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({
            "id"           : str(user.id),
            "email"        : user.email,
            "full_name"    : user.full_name,
            "phone_number" : user.phone_number,
            "role"         : user.role,
            "address"      : user.address,
            "profile_photo": request.build_absolute_uri(user.profile_photo.url) if user.profile_photo else None,
            "created_at"   : user.created_at
        }, status=status.HTTP_200_OK)

    def put(self, request):
        user = request.user
        
        # Update fields
        user.full_name    = request.data.get("full_name", user.full_name)
        user.phone_number = request.data.get("phone_number", user.phone_number)
        user.address = request.data.get("address",user.address)
       # Site assign if cashier
        site_id = request.data.get("site")
        if site_id:
            from parking.models import ParkingSite
            try:
                site = ParkingSite.objects.get(id=site_id)
                user.site = site
            except ParkingSite.DoesNotExist:
                return Response(
                    {"error": "Site not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
        # Photo upload
        if "profile_photo" in request.FILES:
            user.profile_photo = request.FILES["profile_photo"]
        
        user.save()
        
        return Response({
            "message"      : "Profile updated successfully",
            "profile_photo": request.build_absolute_uri(user.profile_photo.url) if user.profile_photo else None
        }, status=status.HTTP_200_OK)
class AccountDeleteView(APIView):
    permission_classes=[IsAuthenticated]

    def delete(self,request):
        password=request.data.get("password")
        if not password:
            return Response(
                {"error": "Password is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if not request.user.check_password(password):
            return Response({"error":"Incorrect Password"},status=status.HTTP_400_BAD_REQUEST)
        request.user.delete()
        return Response({"message":"Account deleted successfully"},status=status.HTTP_200_OK)

class SendOTPView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        phone_number = request.data.get("phone_number")
        if not phone_number:
            return Response(
                {"error":"Phone number required"},
                status = status.HTTP_400_BAD_REQUEST
            )
        try:
            client = Client(
                settings.TWILIO_ACCOUNT_SID,
                settings.TWILIO_AUTH_TOKEN
            )
            client.verify.v2.services(
                settings.TWILIO_VERIFY_SID
            ).verifications.create(
                to= phone_number,
                channel="sms"
            )
            return Response(
                {"message":"OTP sent successfully"},
                status = status.HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"error":str(e)},
                status = status.HTTP_400_BAD_REQUEST
            )
class VerifyOTPView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        phone_number =  request.data.get("phone_number")
        otp_code = request.data.get("otp_code")
        if not phone_number or not otp_code:
            return Response(
                {"error":"Phone number and OTP required"},
                status = status.HTTP_400_BAD_REQUEST
            )
        try:
            client = Client(
                settings.TWILIO_ACCOUNT_SID,
                settings.TWILIO_AUTH_TOKEN
            )
            result =client.verify.v2.services(
                settings.TWILIO_VERIFY_SID
            ).verification_checks.create(
                to = phone_number,
                code = otp_code
            )

            if result.status == "approved":
                return Response(
                    {"message":"OTP verified successfully"},
                    status = status.HTTP_200_OK
                )
            else:
                return Response(
                    {"error":"Invalid OTP"},
                    status = status.HTTP_400_BAD_REQUEST
                )
        except Exception as e:
            return Response(
                {"error":str(e)},
                status= status.HTTP_400_BAD_REQUEST
            )
        

class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get("email")

        if not email:
            return Response(
                {"error":"Email is required"},
                status = status.HTTP_400_BAD_REQUEST
            )
        try:
            user= User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error":"User not found"},
                status = status.HTTP_400_BAD_REQUEST
            )
        otp_code = str(random.randint(100000, 999999))

        cache.set(f"reset_otp_{email}", {
            "code": otp_code,
            "time": time.time()
        }, timeout=300)

        try:
            send_mail(
                subject="Smart Parking - Password Reset OTP",
                message=f"Your password reset OTP is: {otp_code}",
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[email]
            )
            return Response(
                {"message":"OTP sent to email successfully"},
                status = status.HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )

class PasswordResetVerifyView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email    = request.data.get("email")
        otp_code = request.data.get("otp_code")

        if not email or not otp_code:
            return Response(
                {"error": "Email and OTP required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Session se OTP lo
        saved_otp = cache.get(f"reset_otp_{email}")

        if not saved_otp:
            return Response(
                {"error": "OTP expired or not found"},
                status=status.HTTP_400_BAD_REQUEST
            )
        if time.time() - saved_otp["time"] > 300:
            return Response({"error":"OTP Expired"},status=status.HTTP_400_BAD_REQUEST)

        if saved_otp["code"] != otp_code:
            return Response(
                {"error": "Invalid OTP"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # OTP sahi hai — session mein mark karo
        cache.set(f"reset_verified_{email}", True, timeout=300)

        return Response(
            {"message": "OTP verified successfully"},
            status=status.HTTP_200_OK
        )
    

class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get("email")
        new_password = request.data.get("new_password")
        confirm_password = request.data.get("confirm_password")

        if not email or not new_password or not confirm_password:
            return Response(
                {"error":"All fields required"},
                status = status.HTTP_400_BAD_REQUEST 
            )
        if new_password != confirm_password:
            return Response(
                {
                    "error":"Passwords do not match"
                },
                status = status.HTTP_400_BAD_REQUEST
            )
        is_verified = cache.get(f"reset_verified_{email}")

        if not is_verified:
            return Response(
                {"error":"OTP not verified"},
                status = status.HTTP_400_BAD_REQUEST
            )
        try:
            user =User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error": "User not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        user.set_password(new_password)
        user.save()

        cache.delete(f"reset_otp_{email}")
        cache.delete(f"reset_verified_{email}")


        return Response(
            {"message": "Password reset successfully"},
            status=status.HTTP_200_OK
        )

