from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView,
    LoginView,
    LogoutView,
    ProfileView,
    AccountDeleteView,
    SendOTPView,
    VerifyOTPView,
    PasswordResetRequestView,   
    PasswordResetVerifyView,    
    PasswordResetConfirmView    
)

urlpatterns = [
    path("register/", RegisterView.as_view(), name="register"),
    path("login/", LoginView.as_view(), name="login"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("profile/",ProfileView.as_view(), name="profile"), 
    path("delete/", AccountDeleteView.as_view(), name="delete"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("otp/send/", SendOTPView.as_view(), name="send-otp"),
    path("otp/verify/", VerifyOTPView.as_view(), name="verify-otp"),
    path("password/reset/", PasswordResetRequestView.as_view(), name="password-reset"),        
    path("password/verify/", PasswordResetVerifyView.as_view(), name="password-verify"),       
    path("password/confirm/", PasswordResetConfirmView.as_view(), name="password-confirm"),    
]